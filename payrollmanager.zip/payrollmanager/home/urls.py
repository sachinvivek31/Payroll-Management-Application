from django.contrib import admin
from django.urls import path
from home import views

urlpatterns = [
    path("", views.index, name='home'),
    path("signin", views.signin, name='signin'),
    path("signout",views.signout, name="signout"),
    path("profile",views.profile, name="profile"),
    path("mark",views.mark, name="mark"),
    path("attendance",views.attendance, name="attendance"),
    path("allowances",views.allowances, name="allowances"),
    path("salary",views.salary, name="salary"),
    path("slips",views.slips, name="slips"),
    path("leave",views.leave, name="leave"),
    path("employees",views.employees, name="employees"),
    path("calculate",views.calculate, name="calculate"),
    
]