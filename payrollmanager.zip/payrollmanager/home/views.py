from ast import Not
from multiprocessing import context
from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from home.models import Employees
from home.models import Leave
from home.models import Allowances
from home.models import Sal_rec
from django.contrib.auth import get_user_model
from django.contrib.auth import logout, authenticate, login
from django.contrib import messages
from email import message
import random
from datetime import date as date_n

def index(request):
    if(request.user.is_anonymous): 
        return redirect('/signin')
    return render(request, "index.html")

def signin(request):
    if(request.user.is_anonymous == False): 
        return redirect('/')
    if(request.method == "POST"):
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(username=username, password=password)
        if(user is not None):
            login(request, user)
            return redirect('/')
        else: 
            return render(request, 'login.html')
    return render(request, 'login.html')

def signout(request):
    logout(request)
    return redirect('/signin')

def update(request):
    id = request.POST.get('id')
    fname = request.POST.get('fname')
    lname =  request.POST.get('lname')
    email = request.POST.get('email')
    u = User.objects.get(id=id)
    u.first_name = fname
    u.last_name = lname
    u.email = email
    u.save()
    messages.success(request, "Profile Updated Successfully")

def profile(request):
    if(request.method == "POST"):
        update(request)
    all_users = User.objects.values()
    data=[]
    concern=-2
    for i in all_users:
        data.append(i)
    for i in range(len(data)):
        if(str(data[i]['username']) == str(request.user)):
            concern=i
    ll=str(data[concern]['last_login'])
    doj=str(data[concern]['date_joined'])
    staff=""
    admin=""
    if(data[concern]['is_staff']==True and data[concern]['is_superuser']==False):
        staff="Yes"
        admin="No"
    elif(data[concern]['is_staff']==True and data[concern]['is_superuser']==True):
        staff="No"
        admin="Yes"
    context = {
        'data':data[concern],
        'fname':data[concern]['first_name'],
        'lname':data[concern]['last_name'],
        'username':data[concern]['username'],
        'email':data[concern]['email'],
        'last_login':ll[0:ll.index(' ')],
        'doj':doj[0:doj.index(' ')],
        'staff':staff,
        'admin':admin,
        'id':data[concern]['id']
        }
    return render(request, "profile.html", context)

def attendance(request):
    context = {
        'data':list(Leave.objects.values())
    }
    return render(request, "attendance.html", context)

def mark(request):
    context = {
        'data':list(Employees.objects.values())
    }
    return render(request, "mark.html", context)

def allowances(request):
    context = {
        'hra': list(Allowances.objects.values())[0]['hra'],
        'da': list(Allowances.objects.values())[0]['da'],
        'pf': list(Allowances.objects.values())[0]['pf'],
    }
    return render(request, "allowances.html" ,context)

def salary(request):
    context = {
        'data':list(Sal_rec.objects.values())
    }
    return render(request, "salary.html", context)

def slips(request):
    context = {
        'data':list(Employees.objects.values())
    }
    return render(request, "slips.html", context)

def leave(request):
    if(request.method=="POST"):
        empid = request.POST.get('empid')
        found=0
        for i in list(Leave.objects.values()):
            if(i['eid']==empid):
                found=i['id']
        nod = request.POST.get('nod')
        reasons = request.POST.get('reason')
        leaves=0
        if(found != 0):
            leaves= Leave.objects.get(id=found)
            leaves.no_of_days = int(leaves.no_of_days) + int(nod)
            leaves.reason = reasons
        else:
            leaves = Leave(eid=empid, no_of_days=nod, reason=reasons)
        leaves.save()
        messages.success(request, "Leave Saved Successfully")
    context = {
        'data':list(Employees.objects.values())
    }
    return render(request, "leave.html", context)

def employees(request):
    context = {
        'data':list(Employees.objects.values())
    }
    return render(request, "employees.html", context)

def calculate(request):
    if(request.method == "POST"):
        empid = request.POST.get('empid')
        gp = request.POST.get('gp')
        ref = str(chr(random.randint(97,122))+str(random.randint(1,7))+str(random.randint(5,9))+chr(random.randint(100,118)))
        sal_rec = Sal_rec(eid=empid, gross=gp, date=date_n.today(), payref=ref)
        sal_rec.save()
        del_leave = Leave.objects.get(eid=empid)
        del_leave.delete()
        messages.success(request, "Payment Initiated Successfully. Ref. ID : "+str(ref))
    context = {
        'leaves':list(Leave.objects.values()),
        'employee':list(Employees.objects.values()),
        'allowances':list(Allowances.objects.values()),
        'sal_rec':list(Sal_rec.objects.values())
    }
    return render(request, "calculate.html", context)
