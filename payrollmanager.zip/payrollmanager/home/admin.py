from django.contrib import admin
from home.models import Employees
from home.models import Leave
from home.models import Allowances
from home.models import Sal_rec

# Register your models here.
admin.site.register(Employees)
admin.site.register(Leave)
admin.site.register(Allowances)
admin.site.register(Sal_rec)