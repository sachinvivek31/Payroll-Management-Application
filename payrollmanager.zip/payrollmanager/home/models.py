from django.db import models

# Create your models here.
class Employees(models.Model):
    ename = models.CharField(max_length=20)
    eid = models.CharField(max_length=20)
    phno = models.CharField(max_length=10)
    email = models.EmailField()
    address = models.TextField()
    designation = models.TextField()
    basic = models.FloatField()
    def __str__(self):
        return self.eid
class Leave(models.Model):
    eid = models.CharField(max_length=20)
    no_of_days = models.IntegerField()
    reason = models.TextField()
    def __str__(self):
        return self.eid

class Allowances(models.Model):
    hra = models.FloatField()
    da = models.FloatField()
    pf = models.FloatField()
    def __str__(self):
        return "Rates"
    
class Sal_rec(models.Model):
    eid = models.CharField(max_length=20)
    gross = models.FloatField()
    date = models.DateField()
    payref = models.CharField(max_length=20)
    def __str__(self):
        return self.eid